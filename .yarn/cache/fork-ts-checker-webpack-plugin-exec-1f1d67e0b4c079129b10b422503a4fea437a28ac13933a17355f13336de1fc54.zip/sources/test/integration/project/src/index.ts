// Semantic error
const x: number = '1';
