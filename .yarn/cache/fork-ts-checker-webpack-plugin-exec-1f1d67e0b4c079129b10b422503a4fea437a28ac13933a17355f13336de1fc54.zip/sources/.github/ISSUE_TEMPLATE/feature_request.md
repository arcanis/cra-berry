---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

---

## Feature motivation
<!-- Describe the context, the use-case and the advantages of the feature request. -->

## Feature description
<!-- Describe the functional changes that would have to be made -->

## Feature implementation
<!-- Optionally describe the technical changes to be made. -->
