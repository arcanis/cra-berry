<template>
  <div>This is Foo2</div>
</template>
