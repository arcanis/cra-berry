declare function helloWorld(): void;
