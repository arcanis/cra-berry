// Syntactic error
const array = [{} {}];
