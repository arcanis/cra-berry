declare module '*.css' {
  const css = '';

  export default css;
}
