<script lang="ts" src="./test.ts"></script>
