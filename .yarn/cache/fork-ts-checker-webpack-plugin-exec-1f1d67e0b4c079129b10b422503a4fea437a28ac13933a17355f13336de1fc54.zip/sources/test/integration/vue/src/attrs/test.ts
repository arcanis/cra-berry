const a: number = '';
export default { a };
