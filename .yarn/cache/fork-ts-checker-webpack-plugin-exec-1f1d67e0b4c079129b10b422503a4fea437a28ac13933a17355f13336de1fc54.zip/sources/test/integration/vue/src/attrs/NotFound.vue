<template>
  <div>Hello</div>
</template>

<script lang="ts" src="./notfound.ts"></script>
