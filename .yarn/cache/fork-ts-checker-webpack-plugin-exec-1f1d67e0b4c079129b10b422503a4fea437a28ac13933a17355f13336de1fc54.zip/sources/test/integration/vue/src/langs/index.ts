import Vue from "vue";
import ExampleTsx from "./example-tsx.vue";

new Vue({
    components: { ExampleTsx }
});
