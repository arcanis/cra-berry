<script lang="jsx">
/* OK */
import Vue from "vue";
export default Vue.extend({
  name: "ExampleJsx",
  render() {
    const a = 1; // noUnusedLocals
    return <div>Example</div>;
  }
});
</script>
