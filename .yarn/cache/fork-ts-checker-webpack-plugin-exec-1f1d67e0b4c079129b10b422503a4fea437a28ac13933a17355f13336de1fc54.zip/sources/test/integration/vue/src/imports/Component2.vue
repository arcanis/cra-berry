<template>
  <div>This is Component2</div>
</template>
