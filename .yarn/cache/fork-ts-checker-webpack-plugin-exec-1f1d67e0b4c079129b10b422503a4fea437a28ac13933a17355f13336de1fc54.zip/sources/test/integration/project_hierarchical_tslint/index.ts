import { func as anotherFunc } from './lib/func';
import { func as yetAnotherFunc } from './lib/utils/func';

export const func = a => a; // no tslint config here = no errors
