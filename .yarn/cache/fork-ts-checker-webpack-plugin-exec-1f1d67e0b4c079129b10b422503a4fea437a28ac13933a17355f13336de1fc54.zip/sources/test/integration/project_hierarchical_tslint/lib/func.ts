export const func = a => a; // one error here
