import ExampleWild from '@/example-wild.vue';
import Example from './example.vue';

const foo = new Example();
foo.msg = 'foo';

const bar = new ExampleWild();
bar.msg = 'bar';
