/// <reference types="where-am-i" />

import { fortyTwo } from 'please-find-my-export';

helloWorld();
