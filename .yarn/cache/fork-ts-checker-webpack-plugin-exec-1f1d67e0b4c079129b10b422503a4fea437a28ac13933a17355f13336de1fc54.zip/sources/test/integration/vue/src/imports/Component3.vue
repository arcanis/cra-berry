<template>
  <div>This is Component3</div>
</template>
