export const func = a => a; // two errors here
