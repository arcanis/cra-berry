/// <reference types="node" />
import * as fs from 'fs';
export declare class FsHelper {
    static existsSync(filePath: fs.PathLike): boolean;
}
