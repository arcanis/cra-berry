export const fortyTwo = 42;
